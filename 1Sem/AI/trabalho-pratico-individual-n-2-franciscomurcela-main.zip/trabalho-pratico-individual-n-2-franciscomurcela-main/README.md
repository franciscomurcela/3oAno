# ia-si1-tpi2-2024-template
Students working in Python (most students) should ignore folder skel-prolog.
