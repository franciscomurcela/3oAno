
% Semantic network extensions

:- [semantic_network].

query_local(User,E1,RelName,E2,Declarations)
:- ....


%

query(Entity,Assoc,Declarations)
:- ...

%

update_assoc_stats(Assoc,User)
:- ...


% --------------------------

% Constraint search extensions

:- [constraintsearch].

search_all(Problem,Solutions)
:- 


