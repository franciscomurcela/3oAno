#encoding: utf8

# YOUR NAME: Francisco Murcela
# YOUR NUMBER: 108815

# COLLEAGUES WITH WHOM YOU DISCUSSED THIS ASSIGNMENT (names, numbers):
# - ...
# - ...

from semantic_network import *
from constraintsearch import *

class MySN(SemanticNetwork):

    def __init__(self):
        SemanticNetwork.__init__(self)
        # ADD CODE HERE IF NEEDED
        pass
    
    def find_types(self, entity):
        types = []
        for user, relations in self.declarations.items():
            for (e1, rel), e2 in relations.items():
                if e1 == entity and (rel == 'member' or rel == 'subtype'):
                    types.append(e2)
                    types.extend(self.find_types(e2))
        return types

    def query_local(self,user=None,e1=None,rel=None,e2=None):
        self.query_result = []
        for user_key, relations in self.declarations.items():
            for (entity1, relation_name), entity2 in relations.items():
                if (user is None or user_key == user) and (e1 is None or entity1 == e1) and (rel is None or relation_name == rel):
                    if isinstance(entity2, set):
                        for e2_item in entity2:
                            if e2 is None or e2_item == e2:
                                relation = Relation(entity1, relation_name, e2_item)
                                declaration = Declaration(user_key, relation)
                                self.query_result.append(declaration)
                    elif e2 is None or entity2 == e2:
                        relation = Relation(entity1, relation_name, entity2)
                        declaration = Declaration(user_key, relation)
                        self.query_result.append(declaration)
        return self.query_result # Your code must leave the output in
                          # self.query_result, which is returned here

    def query(self,entity,assoc=None):
        self.query_result = self.query_local(e1=entity, rel=assoc)
        self.query_result += self.query_local(e2=entity, rel=assoc)
        
        types = self.find_types(entity)
        for type in types:
            self.query_result += self.query_local(e1=type, rel=assoc)
            self.query_result += self.query_local(e2=type, rel=assoc)
        
        return self.query_result # Your code must leave the output in
                          # self.query_result, which is returned here


    def update_assoc_stats(self,assoc,user=None):
        self.assoc_stats={}
        stats_assoc_e1 = {}
        stats_assoc_e2 = {}
        total_e1 = 0
        total_e2 = 0
        unknown_e1 = 0
        unknown_e2 = 0
        for user_key, relations in self.declarations.items():
            if user is not None and user_key != user:
                continue
            for (entity1, relation_name), entity2 in relations.items():
                if relation_name == assoc:
                    types_e1 = self.find_types(entity1)
                    types_e2 = self.find_types(entity2)
                    if types_e1:
                        total_e1 += 1
                        for type in types_e1:
                            stats_assoc_e1[type] = stats_assoc_e1.get(type, 0) + 1
                    else:
                        unknown_e1 += 1
                    if types_e2:
                        total_e2 += 1
                        for type in types_e2:
                            stats_assoc_e2[type] = stats_assoc_e2.get(type, 0) + 1
                    else:
                        unknown_e2 += 1
        total_e1 = total_e1 - unknown_e1 + unknown_e1 ** (1/2)
        total_e2 = total_e2 - unknown_e2 + unknown_e2 ** (1/2)
        for type in stats_assoc_e1:
            stats_assoc_e1[type] = stats_assoc_e1[type] / total_e1
        for type in stats_assoc_e2:
            stats_assoc_e2[type] = stats_assoc_e2[type] / total_e2
        self.assoc_stats[(assoc, user)] = (stats_assoc_e1, stats_assoc_e2)

class MyCS(ConstraintSearch):

    def __init__(self,domains,constraints):
        ConstraintSearch.__init__(self,domains,constraints)
        # ADD CODE HERE IF NEEDED
        pass   

    def search_all(self,domains=None,xpto=None):
        self.calls += 1

        if domains is None:
            domains = self.domains

        # If any variable has an empty domain list, fail
        if any([lv == [] for lv in domains.values()]):
            return []

        # If all variables have only one possible value, success
        if all([len(lv) == 1 for lv in domains.values()]):
            # If values violate constraints, fail
            for (var1, var2) in self.constraints:
                constraint = self.constraints[var1, var2]
                if not constraint(var1, domains[var1][0], var2, domains[var2][0]):
                    return []
            return [{v: lv[0] for (v, lv) in domains.items()}]

        # Continue the search
        solutions = []
        for var in domains:
            if len(domains[var]) > 1:
                for val in domains[var]:
                    new_domains = dict(domains)
                    new_domains[var] = [val]
                    solution = self.search(new_domains)
                    if solution is not None:
                        solutions.append(solution)
        return solutions

