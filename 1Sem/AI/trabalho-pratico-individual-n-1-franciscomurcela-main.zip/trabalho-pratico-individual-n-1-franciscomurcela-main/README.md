# ia-si1-tpi-1-2024-template
Trabalho Pratico Individual nº
