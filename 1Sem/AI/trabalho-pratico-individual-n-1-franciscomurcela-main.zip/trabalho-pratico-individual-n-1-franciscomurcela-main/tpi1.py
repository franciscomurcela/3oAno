#STUDENT NAME: Francisco Murcela
#STUDENT NUMBER:    108815

#DISCUSSED TPI-1 WITH: (names and numbers):
#Tiago Fonseca 107266
import math
from tree_search import *

class OrderDelivery(SearchDomain):
    def __init__(self,connections, coordinates):
        self.connections = connections
        self.coordinates = coordinates

    def actions(self,state):
        city = state[0]
        actlist = []
        for (C1,C2,D) in self.connections:
            if (C1==city):
                actlist += [(C1,C2)]
            elif (C2==city):
               actlist += [(C2,C1)]
        return actlist 

    def result(self,state,action):
        (cidade1,cidade2)=action
        if (cidade1==state[0]):
            return (cidade2,state[0])
        #iteração para o próximo estado

    def satisfies(self, state, goal):
        if (state[0]==goal):
            return True
        else:
            return False
        #verifica se chegou ao destino pretendido

    def cost(self, state, action):
        print(action)
        (cidade1,cidade2)=action
        print (action)
        for (estado1,estado2,custo) in self.connections:
            if (cidade1==estado1 and cidade2==estado2) or (cidade1==estado2 and cidade2==estado1):
                return custo
        #retorna o custo de uma ação

    def heuristic(self, state, goal):
        (cidade1,cidade2)=state
        (cidade3,cidade4)=goal
        h1=math.sqrt((self.coordinates[cidade1][0]-self.coordinates[cidade2][0])**2+(self.coordinates[cidade1][1]-self.coordinates[cidade2][1])**2)+math.sqrt((self.coordinates[cidade3][0]-self.coordinates[cidade4][0])**2+(self.coordinates[cidade3][1]-self.coordinates[cidade4][1])**2)
        return h1
        #retorna a heuristica


 
class MyNode(SearchNode):

    def __init__(self,state,parent,action):
        super().__init__(state,parent)
        self.depth=0
        self.cost=0
        self.heuristic=0
        self.eval=self.cost+self.heuristic 
        self.marcado=False
        self.action=action
        #inicialização dos atributos dos nós

class MyTree(SearchTree):

    def __init__(self,problem, strategy='breadth',maxsize=None):
        super().__init__(problem,strategy)
        self.non_terminals=0
        self.terminals=0
        self.maxsize=maxsize

    def astar_add_to_open(self,lnewnodes):
        self.open_nodes=sorted(self.open_nodes + lnewnodes, key=lambda node: (node.eval,node.state)) #dá sort á lista de open nodes + os novos nós por valor e eval e, em caso de empate, por ordem alfabética

    def search2(self):
        while self.open_nodes!=[]:
            node=self.open_nodes.pop(0)                     #analisa o primeiro nó da lista de nós abertos
            if node.parent==None:                           #se o nó não tiver pai
                node.depth=0                                
                node.cost=0                                 #é a root
            if self.problem.goal_test(node.state):          #se o nó for o destino
                self.solution=node                          #esse nó é a solução
                self.terminals=len(self.open_nodes)+1       #fecha os nós abertos e adiciona o nó de destino aos nós terminais
                return self.get_path(node)                  #retorna o caminho para o nó destino
            self.non_terminals=self.non_terminals+1                           #senão incrementa o número de nós não terminais
            lnewnodes=[]
            for a in self.problem.domain.actions(node.state):
                newstate=self.problem.domain.result(node.state,a)
                if newstate not in self.get_path(node):
                    newnode=SearchNode(newstate,node)
                    newnode.depth=node.depth+1
                    newnode.cost=node.cost+self.problem.domain.cost(node.state,a)
                    newnode.heuristic=self.problem.domain.heuristic(newstate,self.problem.goal)
                    newnode.eval=newnode.cost+newnode.heuristic
                    newnode.marcado=False
                    lnewnodes.append(newnode)               #e adiciona nós á lista de nos abertos 
            self.add_to_open(lnewnodes)
        if (self.strategy=='A*' and self.maxsize!=None and len(self.open_nodes)+self.terminals>self.maxsize):      # se a estrategia for astar e o maxsize estiver definido, verifica se com a expansão dos nós abertos, o tamanho máximo da árvore excede o treshold definido 
            self.manage_memory()        #se exceder, chama manage_memory
    
    def manage_memory(self):
        len_tree=len(self.open_nodes)+(self.non_terminals)
        while len_tree>self.maxsize:                    #se o tamanho da árvore exceder o threshold elimina nós marcados
            for node in reversed(self.open_nodes):      #procura nó na lista sorted pelo eval reversed para dar o maior eval primeiro
                if node.marcado==False:                  #verifica se ta marcado
                    node.marcado=True
                    siblings=[] 
                    siblings_marcardos=[]      
                    for sibling_node in self.open_nodes:
                        if sibling_node.parent==node.parent:
                            siblings.append(sibling_node)
                    for x in siblings:
                        if x.marcado==True:
                            siblings_marcardos.append(x)
                    for x in siblings_marcardos:
                        self.open_nodes.remove(x)
                        self.terminals=self.terminals-1

                    parent_eval=min(eval(siblings_marcardos))
                    self.open_nodes.remove(node)
                    self.terminals=self.terminals-1                 #decrementa o nó filho
                    self.non_terminals=self.non_terminals+1         #pai passa a ser nó não terminal
                    node.parent.eval=parent_eval                #eval do pai passa a ser o menor dos filhos
                    self.open_nodes.append(node.parent)         #adiciona o pai à lista de nós abertos
                len_tree=len(self.open_nodes)+(self.non_terminals)                  #atualiza o tamanho da árvore
                   


def orderdelivery_search(domain,city,targetcities,strategy='breadth',maxsize=None):
    state=(city,None)
    problem=SearchProblem(domain,state,targetcities[0])   #cria o problema
    tree=MyTree(problem,strategy,maxsize)    #cria a árvore
    return (tree,tree.search2())       #(t,path)

