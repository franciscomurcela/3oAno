//
// Algoritmos e Estruturas de Dados --- 2023/2024
//
// Topological Sorting
//

#include "GraphTopologicalSorting.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include "Graph.h"
#include "IntegersQueue.h"
#include "instrumentation.h"


#define GRAPH_NO_VERTEX ((unsigned int)-1)

struct _GraphTopoSort {
  int* marked;                     // Aux array
  unsigned int* numIncomingEdges;  // Aux array
  unsigned int* vertexSequence;    // The result
  int validResult;                 // 0 or 1
  unsigned int numVertices;        // From the graph
  Graph* graph;
};

// AUXILIARY FUNCTION
// Allocate memory for the struct
// And for its array fields
// Initialize all struct fields
//
static GraphTopoSort* _create(Graph* g) {
  assert(g != NULL);

  //Aloca memória para a estrutura do GraphTopoSort
  GraphTopoSort* p = (GraphTopoSort*)malloc(sizeof(GraphTopoSort));
  assert(p != NULL);

  //Inicializa o graph
  p->graph = g;

  //Inicializa o numvertices com o numero de vertices em g
  p->numVertices = GraphGetNumVertices(g);

  //Aloca memória para o array  marked
  p->marked = (int*)calloc(p->numVertices, sizeof(int));
  assert(p->marked != NULL);

  //Aloca memória para o array numIncomingEdges
  p->numIncomingEdges = (unsigned int*)calloc(p->numVertices, sizeof(unsigned int));
  assert(p->numIncomingEdges != NULL);

  //Aloca memória para o array vertexSequence
  p->vertexSequence = (unsigned int*)calloc(p->numVertices, sizeof(unsigned int));
  assert(p->vertexSequence != NULL);

  //Inicializa o validResult como 0
  p->validResult = 0;

  return p;
}


//
// Computing the topological sorting, if any, using the 1st algorithm:
// 1 - Create a copy of the graph
// 2 - Successively identify vertices without incoming edges and remove their
//     outgoing edges
// Check if a valid sorting was computed and set the isValid field
// For instance, by checking if the number of elements in the vertexSequence is
// the number of graph vertices
//
GraphTopoSort* GraphTopoSortComputeV1(Graph* g) {
  assert(g != NULL && GraphIsDigraph(g) == 1);

  //Cria e inicializa a estrutura
  GraphTopoSort* topoSort = _create(g);//O(1)

  //Cria uma cópia do grafo
  Graph* gCopy = GraphCopy(g);//O(1)
  assert(gCopy != NULL);

  //Cria uma lista que pega em vértices sem arestas de entrada
  Queue* queue = QueueCreate(topoSort->numVertices);//O(1)

  //Adiciona vértices sem arestas de entrada à fila
  for (unsigned int i = 0; i < topoSort->numVertices; i++) {//O(V)-> V constante de numVertices;
    topoSort->numIncomingEdges[i] = GraphGetNumEdges(gCopy);//O(1)
    if (topoSort->numIncomingEdges[i] == 0) {
      QueueEnqueue(queue, i);
    }//O(1)
  }

  // Identifica sucessivamente vértices sem arestas de entrada e remove as arestas de saída
  unsigned int sequenceIndex = 0;
  while (!QueueIsEmpty(queue)) {//O(log N)-> para o ciclo while;
    unsigned int vertex = QueueDequeue(queue);
    topoSort->vertexSequence[sequenceIndex++] = vertex;

    unsigned int* adjacents = GraphGetAdjacentsTo(gCopy, vertex);//O(A)
    for (unsigned int i = 0; adjacents[i] != GRAPH_NO_VERTEX; i++) {//O(D)--D->numero de adjacentes de um vertice no grafo
      topoSort->numIncomingEdges[adjacents[i]]--;
      if (topoSort->numIncomingEdges[adjacents[i]] == 0) {
        QueueEnqueue(queue, adjacents[i]);
      }//O(1)
    }
    free(adjacents);
  }//O(log N)* (O(A)+ O(D))

  topoSort->validResult = (sequenceIndex == topoSort->numVertices);

  QueueDestroy(&queue);
  GraphDestroy(&gCopy);//O(V*E)

  return topoSort;
}//O(V)+ (O(log N)* (O(A)+ O(D))) + O(V*E)--> complexidade desta funçao


//
// Computing the topological sorting, if any, using the 2nd algorithm
// Check if a valid sorting was computed and set the isValid field
// For instance, by checking if the number of elements in the vertexSequence is
// the number of graph vertices
//
// Auxiliary function for depth-first search
static void dfs(Graph* g, int v, int* visited, unsigned int* sequence, unsigned int* index) {
    visited[v] = 1;
    unsigned int* adjacents = GraphGetAdjacentsTo(g, v);//O(A)
    for (unsigned int i = 0; adjacents[i] != GRAPH_NO_VERTEX; i++) {//O(D)
        if (!visited[adjacents[i]]) {
            dfs(g, adjacents[i], visited, sequence, index);
        }
    }
    sequence[(*index)++] = v;
    free(adjacents);
}//O(A)+O(D)

GraphTopoSort* GraphTopoSortComputeV2(Graph* g) {
    assert(g != NULL && GraphIsDigraph(g) == 1);

    //Cria e inicializa a estrutura
    GraphTopoSort* topoSort = _create(g);//O(1)

    //Constroi a estrutura topológica
    int* visited = (int*)calloc(topoSort->numVertices, sizeof(int));
    unsigned int index = 0;
    for (unsigned int i = 0; i < topoSort->numVertices; i++) {//O(V)
        if (!visited[i]) {
            dfs(g, i, visited, topoSort->vertexSequence, &index);//O(A)+O(D)
        }
    }//O(V)*(O(A)+O(D))
    free(visited);

    //Reverte a sequência para obter a ordem topológica correta
    for (unsigned int i = 0; i < topoSort->numVertices / 2; i++) {//O(Z)--Z-->numvertices(V)/2
        unsigned int temp = topoSort->vertexSequence[i];
        topoSort->vertexSequence[i] = topoSort->vertexSequence[topoSort->numVertices - i - 1];
        topoSort->vertexSequence[topoSort->numVertices - i - 1] = temp;
    }

    topoSort->validResult = (index == topoSort->numVertices);

    return topoSort;
}//(O(V)*(O(A)+ O(D)))+ O(Z)

//
// Computing the topological sorting, if any, using the 3rd algorithm
// Check if a valid sorting was computed and set the isValid field
// For instance, by checking if the number of elements in the vertexSequence is
// the number of graph vertices
//
GraphTopoSort* GraphTopoSortComputeV3(Graph* g) {
    assert(g != NULL && GraphIsDigraph(g) == 1);

    //Cria e inicializa a estrutura
    GraphTopoSort* topoSort = _create(g);//O(1)

    //Constrói uma organização topológica
    int* visited = (int*)calloc(topoSort->numVertices, sizeof(int));
    unsigned int* stack = (unsigned int*)malloc(topoSort->numVertices * sizeof(unsigned int));
    unsigned int index = 0;

     //Executa a funçao dfs em todos os vértices não visitados
    for (unsigned int i = 0; i < topoSort->numVertices; i++) {//O(V)
        if (!visited[i]) {
            dfs(g, i, visited, stack, &index);//O(A)+ O(D)
        }
    }

    //Copia o stack para vertexSequence numa ordem reversiva
    for (unsigned int i = 0; i < topoSort->numVertices; i++) {
        topoSort->vertexSequence[i] = stack[topoSort->numVertices - i - 1];
    }//O(V)

    //Verifica se a ordenação topológica foi calculada corretamente
    topoSort->validResult = (index == topoSort->numVertices);

    //
    free(visited);
    free(stack);

    return topoSort;
}//( O(V)* (O(A)+ O(D)) )+ O(V)


void GraphTopoSortDestroy(GraphTopoSort** p) {
  assert(*p != NULL);

  GraphTopoSort* aux = *p;

  free(aux->marked);
  free(aux->numIncomingEdges);
  free(aux->vertexSequence);

  free(*p);
  *p = NULL;
}

//
// A valid sorting was computed?
//
int GraphTopoSortIsValid(const GraphTopoSort* p) { return p->validResult; }

//
// Getting an array containing the topological sequence of vertex indices
// Or NULL, if no sequence could be computed
// MEMORY IS ALLOCATED FOR THE RESULTING ARRAY
//
unsigned int* GraphTopoSortGetSequence(const GraphTopoSort* p) {
    assert(p != NULL);

    if (!p->validResult) {
        return NULL;
    }

    unsigned int* sequenceCopy = (unsigned int*)malloc(p->numVertices * sizeof(unsigned int));
    assert(sequenceCopy != NULL);

    for (unsigned int i = 0; i < p->numVertices; i++) {
        sequenceCopy[i] = p->vertexSequence[i];
    }

    return sequenceCopy;
}

// DISPLAYING on the console

//
// The toplogical sequence of vertex indices, if it could be computed
//
void GraphTopoSortDisplaySequence(const GraphTopoSort* p) {
  assert(p != NULL);

  if (p->validResult == 0) {
    printf(" *** The topological sorting could not be computed!! *** \n");
    return;
  }

  printf("Topological Sorting - Vertex indices:\n");
  for (unsigned int i = 0; i < GraphGetNumVertices(p->graph); i++) {
    printf("%d ", p->vertexSequence[i]);
  }
  printf("\n");
}

//
// The toplogical sequence of vertex indices, if it could be computed
// Followed by the digraph displayed using the adjecency lists
// Adjacency lists are presented in topologic sorted order
//
void GraphTopoSortDisplay(const GraphTopoSort* p) {
  assert(p != NULL);

  // The topological order
  GraphTopoSortDisplaySequence(p);

  if (p->validResult == 0) {
    return;
  }

  // The Digraph
  for (unsigned int i = 0; i < GraphGetNumVertices(p->graph); i++) {
    GraphListAdjacents(p->graph, p->vertexSequence[i]);
  }
  printf("\n");
}