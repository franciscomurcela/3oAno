package com.example.custom_tabbar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
